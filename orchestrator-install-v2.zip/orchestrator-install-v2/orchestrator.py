#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LinkGuard / TLB-WG Orchestrator (XML-RPC) - v4

Cambios v1 → v2:
  SEC-01/02: Tokens obligatorios al arranque; no arranca con valores inseguros
  SEC-03:    Autenticación requerida cuando ORCH_TOKEN está configurado
  SEC-04:    JWT secret recargable sin reinicio (rotación en caliente)
  EST-01:    Backup automático rotativo configurable
  EST-02:    IPs devueltas al pool al desregistrar peers
  EST-03:    Historial de eventos en archivo JSONL rotativo independiente
  EST-04:    Lista de revocación JWT en archivo separado; purga solo JTIs expirados
  HA-04:     Reintentos con backoff exponencial en llamadas al hub-agent
  ESC-01:    Locks granulares por recurso (PEERS, NETWORKS, USERS, EVENTS, STATE)
  ESC-02:    Servidor XML-RPC con ThreadingMixIn (requests concurrentes)
  ESC-03:    Quotas de peers y redes por tenant
  MT-01:     Usuarios legacy solo ven redes shared (user_id is None)
  MT-02:     Log de auditoría para auto-aprobaciones; AUTO_APPROVE_REQUIRE_CONFIRM
  MT-03:     Usuarios JWT ven eventos de sus propios recursos
  OPS-02:    Verificación de dependencias del sistema al arranque

Cambios v2 → v3 (Mesh Topology):
  MESH-F1a:  network_create valida enum topology ('hub-spoke'|'mesh') y almacena mesh_keepalive
  MESH-F1b:  peer_register almacena mesh_listen_port desde metadata
  MESH-F1c:  peer_heartbeat detecta cambio de endpoint y hace bump de config_version
  MESH-F2a:  config_get_peer_config bifurca según topology; inyecta mesh_peers[] en redes mesh
  MESH-F2b:  nuevo endpoint config.get_mesh_peers(peer_id, network_id, token)
  MESH-F2c:  nuevo endpoint network.set_topology(network_id, topology, admin_token)

Cambios v3 → v4 (Hub-Mesh Topology — directas + HUB como relay de fallback):
  HM-F1a:   VALID_TOPOLOGIES incluye 'hub-mesh'; network_create almacena hub_mesh_relay_fallback_cidr
  HM-F1b:   peer_register almacena nat_type, relay_mode, reachability_map, last_direct_handshake_ts
  HM-F2a:   peer_heartbeat lee nat_type del status y hace bump en redes hub-mesh si cambia
  HM-F2b:   _classify_peers_for_hub_mesh: clasifica peers en direct / relay_only
  HM-F2c:   nuevo endpoint peer.report_reachability(peer_id, target, reachable, token)
  HM-F3a:   config_get_peer_config bifurca para hub-mesh: HUB=/CIDR, directos=/32, relay sin bloque
  HM-F3b:   config_get_mesh_peers soporta hub-mesh; devuelve clasificación direct/relay_only
  HM-F3c:   network_set_topology permite hub-mesh; hub-mesh sí permitido en la red default
"""

import os
import json
import time
import hashlib
import threading
import ipaddress
import secrets
import logging
from socketserver import ThreadingMixIn
from typing import Dict, Any, Optional, List, Tuple
from xmlrpc.server import SimpleXMLRPCServer, SimpleXMLRPCRequestHandler
from xmlrpc.client import ServerProxy

import jwt  # PyJWT


# =========================
# LOGGING
# =========================
logging.basicConfig(
    level=logging.INFO,
    format="[orchestrator] %(asctime)s %(levelname)s %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)
logger = logging.getLogger("orchestrator")


def log(msg: str) -> None:
    logger.info(msg)


# =========================
# CONFIG
# =========================
ORCH_BIND = os.getenv("ORCH_BIND", "0.0.0.0")
ORCH_PORT = int(os.getenv("ORCH_PORT", "8000"))
STATE_PATH = os.getenv("ORCH_STATE_PATH", "/var/lib/wg-orchestrator/state.json")

HUB_AGENT_URL = os.getenv("HUB_AGENT_URL", "http://127.0.0.1:9000")
HUB_AGENT_TOKEN = os.getenv("HUB_AGENT_TOKEN", "")
HUB_ENDPOINT = os.getenv("HUB_ENDPOINT", "")

ORCH_TOKEN = os.getenv("ORCH_TOKEN", "")
ADMIN_TOKEN = os.getenv("ADMIN_TOKEN", "")

JWT_SECRET_PATH = os.getenv("JWT_SECRET_PATH", "/etc/linkguard/jwt_secret")
JWT_ISSUER = os.getenv("JWT_ISSUER", "linkguard-orchestrator")
JWT_AUDIENCE = os.getenv("JWT_AUDIENCE", "linkguard")
JWT_TTL_DEFAULT = int(os.getenv("JWT_TTL_DEFAULT", "600"))

HEARTBEAT_TTL_SEC = int(os.getenv("HEARTBEAT_TTL_SEC", "180"))

AUTO_APPROVE_ENABLED = os.getenv("AUTO_APPROVE_ENABLED", "0") == "1"
AUTO_APPROVE_RULES_RAW = os.getenv("AUTO_APPROVE_RULES", "").strip()
# MT-02: requiere confirmación manual antes de auto-aprobar
AUTO_APPROVE_REQUIRE_CONFIRM = os.getenv("AUTO_APPROVE_REQUIRE_CONFIRM", "0") == "1"

DEFAULT_NET_ID = os.getenv("DEFAULT_NET_ID", "default")
DEFAULT_NET_CIDR = os.getenv("DEFAULT_NET_CIDR", "10.20.30.0/24")
WG_PEER_ALLOWED_FMT = os.getenv("WG_PEER_ALLOWED_FMT", "{ip}/32")

# EST-01: Backup automático
BACKUP_ENABLED = os.getenv("BACKUP_ENABLED", "1") == "1"
BACKUP_DIR = os.getenv("BACKUP_DIR", "/var/lib/wg-orchestrator/backups")
BACKUP_MAX_KEEP = int(os.getenv("BACKUP_MAX_KEEP", "10"))
BACKUP_INTERVAL_SEC = int(os.getenv("BACKUP_INTERVAL_SEC", "300"))

# EST-03: Eventos JSONL separados
EVENTS_LOG_PATH = os.getenv("EVENTS_LOG_PATH", "/var/lib/wg-orchestrator/events.jsonl")
EVENTS_IN_STATE_MAX = int(os.getenv("EVENTS_IN_STATE_MAX", "200"))

# EST-04: Revocación JWT separada
JWT_REVOKED_PATH = os.getenv("JWT_REVOKED_PATH", "/var/lib/wg-orchestrator/jwt_revoked.json")

# ESC-03: Quotas por tenant
DEFAULT_MAX_PEERS = int(os.getenv("DEFAULT_MAX_PEERS", "50"))
DEFAULT_MAX_NETWORKS = int(os.getenv("DEFAULT_MAX_NETWORKS", "10"))

# HA-04: Reintentos hub-agent
HUB_RETRY_COUNT = int(os.getenv("HUB_RETRY_COUNT", "3"))
HUB_RETRY_DELAY = float(os.getenv("HUB_RETRY_DELAY", "1.0"))

# MESH / HUB-MESH: Topologías peer-a-peer
VALID_TOPOLOGIES       = {"hub-spoke", "mesh", "hub-mesh"}  # HM-F1a: hub-mesh añadido
MESH_DEFAULT_KEEPALIVE = int(os.getenv("MESH_DEFAULT_KEEPALIVE", "25"))
MESH_MAX_PEERS         = int(os.getenv("MESH_MAX_PEERS", "50"))  # máx peers vivos en config

# HM-F1a: TTL de handshake directo — si un peer no confirma handshake en este tiempo se vuelve relay
HUB_MESH_DIRECT_TTL    = int(os.getenv("HUB_MESH_DIRECT_TTL", "300"))  # seg

# =========================
# ESC-01: LOCKS GRANULARES
# orden de adquisición: USERS → NETWORKS → PEERS → EVENTS (nunca invertir)
# =========================
LOCK_PEERS    = threading.RLock()
LOCK_NETWORKS = threading.RLock()
LOCK_USERS    = threading.RLock()
LOCK_EVENTS   = threading.RLock()
LOCK_STATE    = threading.RLock()
LOCK_REVOKED  = threading.RLock()


def now_ts() -> int:
    return int(time.time())


def ensure_dir(path: str) -> None:
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)


def load_json(path: str) -> Dict[str, Any]:
    try:
        with open(path, "r") as f:
            return json.load(f)
    except Exception:
        return {}


def save_json(path: str, data: Dict[str, Any]) -> None:
    ensure_dir(path)
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f, indent=2, sort_keys=True)
    os.replace(tmp, path)


# =========================
# OPS-02: Verificación de dependencias
# =========================
def check_dependencies() -> None:
    import shutil
    required = [("python3", "Python 3")]
    missing = [name for cmd, name in required if not shutil.which(cmd)]
    if missing:
        raise RuntimeError(
            f"Dependencias faltantes: {', '.join(missing)}. "
            "Instala los paquetes requeridos antes de iniciar el orchestrator."
        )
    log("Verificación de dependencias: OK")


# =========================
# SEC-01/02: Tokens seguros al arranque
# =========================
INSECURE_TOKENS = {"changeme", "changeme-super-secret", "secret", "password", "12345", ""}


def validate_tokens_at_startup() -> None:
    errors = []
    if not ADMIN_TOKEN:
        errors.append(
            "ADMIN_TOKEN está vacío. Genera uno con: openssl rand -hex 32"
        )
    elif ADMIN_TOKEN.lower() in INSECURE_TOKENS:
        errors.append(f"ADMIN_TOKEN tiene un valor inseguro ('{ADMIN_TOKEN}'). Usa un token aleatorio seguro.")

    if not HUB_AGENT_TOKEN:
        errors.append("HUB_AGENT_TOKEN está vacío. Genera uno con: openssl rand -hex 32")
    elif HUB_AGENT_TOKEN.lower() in INSECURE_TOKENS:
        errors.append(f"HUB_AGENT_TOKEN tiene un valor inseguro ('{HUB_AGENT_TOKEN}').")

    if not HUB_ENDPOINT:
        errors.append("HUB_ENDPOINT está vacío (ej: 1.2.3.4:51820).")

    if errors:
        for e in errors:
            logger.critical("CONFIGURACIÓN INSEGURA: %s", e)
        raise SystemExit(
            "\n[ERROR CRÍTICO] El orchestrator no puede arrancar con la configuración actual.\n"
            "Corrige las variables de entorno listadas arriba.\n"
            "Consulta install.sh para generar tokens seguros automáticamente."
        )
    log("Validación de tokens de arranque: OK")


# =========================
# SEC-04: JWT secret recargable sin reinicio
# =========================
_JWT_SECRET_HASH: Optional[str] = None
_JWT_SECRET_VALUE: Optional[str] = None
_JWT_SECRET_LOCK = threading.Lock()


def _read_jwt_secret() -> str:
    global _JWT_SECRET_HASH, _JWT_SECRET_VALUE
    try:
        with open(JWT_SECRET_PATH, "r") as f:
            s = f.read().strip()
        if not s:
            raise RuntimeError("JWT secret vacío")
        file_hash = hashlib.sha256(s.encode()).hexdigest()
        with _JWT_SECRET_LOCK:
            if file_hash != _JWT_SECRET_HASH:
                _JWT_SECRET_HASH = file_hash
                _JWT_SECRET_VALUE = s
                log("JWT secret recargado (hash cambió)")
            return _JWT_SECRET_VALUE
    except FileNotFoundError:
        raise RuntimeError(
            f"JWT secret no existe: {JWT_SECRET_PATH}. "
            "Crea con: openssl rand -hex 32 > {JWT_SECRET_PATH} && chmod 600 {JWT_SECRET_PATH}"
        )
    except Exception as e:
        raise RuntimeError(f"No pude leer JWT secret: {e}")


# =========================
# JWT helpers
# =========================
def _jwt_encode(payload: Dict[str, Any], ttl_seconds: int) -> Tuple[str, int]:
    ttl = int(ttl_seconds) if ttl_seconds else JWT_TTL_DEFAULT
    if ttl <= 0:
        ttl = JWT_TTL_DEFAULT
    n = now_ts()
    exp = n + ttl
    full = dict(payload)
    full.update({
        "iss": JWT_ISSUER, "aud": JWT_AUDIENCE,
        "iat": n, "nbf": n, "exp": exp,
        "jti": secrets.token_hex(12),
    })
    token = jwt.encode(full, _read_jwt_secret(), algorithm="HS256")
    return token, exp


def _jwt_decode(token: str) -> Dict[str, Any]:
    return jwt.decode(
        token, _read_jwt_secret(), algorithms=["HS256"],
        audience=JWT_AUDIENCE, issuer=JWT_ISSUER,
        options={"require": ["exp", "iat", "nbf", "iss", "aud", "jti"]},
    )


def _is_probably_jwt(token: str) -> bool:
    return isinstance(token, str) and token.count(".") == 2 and len(token) > 30


# =========================
# EST-04: Revocación JWT en archivo separado
# =========================
_REVOKED_CACHE: Optional[Dict[str, Any]] = None


def _load_revoked() -> Dict[str, Any]:
    global _REVOKED_CACHE
    if _REVOKED_CACHE is not None:
        return _REVOKED_CACHE
    data = load_json(JWT_REVOKED_PATH)
    _REVOKED_CACHE = data if isinstance(data, dict) else {}
    return _REVOKED_CACHE


def _save_revoked(rev: Dict[str, Any]) -> None:
    global _REVOKED_CACHE
    save_json(JWT_REVOKED_PATH, rev)
    _REVOKED_CACHE = rev


def _is_revoked_jti(jti: str) -> bool:
    with LOCK_REVOKED:
        return jti in _load_revoked()


def _revoke_jti(jti: str, reason: str, exp: Optional[int] = None) -> None:
    with LOCK_REVOKED:
        rev = _load_revoked()
        rev[str(jti)] = {"ts": now_ts(), "reason": reason, "exp": exp or 0}
        # Purga solo JTIs cuyo exp ya pasó (EST-04: nunca purgar vigentes)
        now = now_ts()
        rev = {k: v for k, v in rev.items()
               if v.get("exp", 0) == 0 or v.get("exp", 0) > now}
        _save_revoked(rev)


# =========================
# Auth helpers
# =========================
def _auth_from_token(token: Optional[str]) -> Tuple[str, Optional[str], List[str], bool]:
    if token and _is_probably_jwt(token):
        payload = _jwt_decode(token)
        jti = str(payload.get("jti") or "")
        if jti and _is_revoked_jti(jti):
            raise PermissionError("jwt revoked")
        user_id = payload.get("user_id")
        scopes = payload.get("scopes") or []
        role = payload.get("role") or "user"
        if not isinstance(scopes, list):
            scopes = []
        return "jwt", user_id, [str(x) for x in scopes], (role == "admin")

    if token:
        return "legacy", None, [], False
    return "none", None, [], False


def _require_scope(scopes: List[str], needed: str) -> None:
    if needed in scopes:
        return
    prefix = needed.split(":", 1)[0] + ":*"
    if prefix in scopes or "*:*" in scopes or "*" in scopes:
        return
    raise PermissionError(f"missing scope: {needed}")


# SEC-03: auth obligatoria cuando ORCH_TOKEN está configurado
def _require_auth(token: Optional[str]) -> None:
    if ORCH_TOKEN and not token:
        raise PermissionError("authentication required: provide JWT or ORCH_TOKEN")


def orch_check_legacy_user_token(token: Optional[str]) -> None:
    raise PermissionError("legacy ORCH_TOKEN auth is disabled; use auth_login() to obtain a JWT")


def orch_check_admin_token(token: Optional[str]) -> None:
    if not ADMIN_TOKEN:
        raise PermissionError("admin token not configured")
    if not token:
        raise PermissionError("admin token required")
    if token != ADMIN_TOKEN:
        raise PermissionError("invalid admin token")


# =========================
# HA-04: HUB RPC con reintentos
# =========================
def get_hub_client() -> ServerProxy:
    return ServerProxy(HUB_AGENT_URL, allow_none=True)


def _hub_call_with_retry(method: str, *args) -> Any:
    last_exc = None
    for attempt in range(HUB_RETRY_COUNT):
        try:
            c = get_hub_client()
            return c.__getattr__(method)(*args)
        except Exception as e:
            last_exc = e
            if attempt < HUB_RETRY_COUNT - 1:
                delay = HUB_RETRY_DELAY * (2 ** attempt)
                log(f"hub-agent '{method}' falló (intento {attempt+1}/{HUB_RETRY_COUNT}): {e}. Reintentando en {delay:.1f}s...")
                time.sleep(delay)
    raise RuntimeError(f"hub-agent '{method}' falló tras {HUB_RETRY_COUNT} intentos: {last_exc}")


def hub_public_key() -> str:
    return str(_hub_call_with_retry("hub.public_key", HUB_AGENT_TOKEN)).strip()

def hub_ensure_base_rules() -> bool:
    return bool(_hub_call_with_retry("hub.ensure_base_rules", HUB_AGENT_TOKEN))

def hub_apply_peer(pub: str, allowed_ips_csv: str) -> bool:
    return bool(_hub_call_with_retry("hub.apply_peer", HUB_AGENT_TOKEN, pub, allowed_ips_csv))

def hub_remove_peer(pub: str) -> bool:
    return bool(_hub_call_with_retry("hub.remove_peer", HUB_AGENT_TOKEN, pub))


# =========================
# STATE
# =========================
DEFAULT_STATE = {
    "version": 4,
    "config_version": 1,
    "users": {},
    "peers": {},
    "networks": {},
    "events": [],
    # jwt_revoked movido a archivo separado (EST-04)
}

STATE: Dict[str, Any] = {}


# =========================
# EST-03: Eventos en JSONL separado
# =========================
def _append_event_to_log(ev: Dict[str, Any]) -> None:
    try:
        ensure_dir(EVENTS_LOG_PATH)
        with open(EVENTS_LOG_PATH, "a") as f:
            f.write(json.dumps(ev, sort_keys=True) + "\n")
    except Exception as e:
        log(f"WARNING: No pude escribir evento en log: {e}")


def add_event(kind: str, detail: Dict[str, Any]) -> None:
    ev = {"ts": now_ts(), "kind": kind, "detail": detail}
    _append_event_to_log(ev)
    with LOCK_EVENTS:
        STATE["events"].append(ev)
        if len(STATE["events"]) > EVENTS_IN_STATE_MAX:
            STATE["events"] = STATE["events"][-EVENTS_IN_STATE_MAX:]


# =========================
# EST-01: Backup automático
# =========================
def _do_backup() -> None:
    if not BACKUP_ENABLED:
        return
    try:
        os.makedirs(BACKUP_DIR, exist_ok=True)
        ts = time.strftime("%Y%m%dT%H%M%S")
        backup_path = os.path.join(BACKUP_DIR, f"state-{ts}.json")
        with LOCK_STATE:
            save_json(backup_path, STATE)
        backups = sorted([f for f in os.listdir(BACKUP_DIR)
                          if f.startswith("state-") and f.endswith(".json")])
        for old in backups[:-BACKUP_MAX_KEEP]:
            try:
                os.remove(os.path.join(BACKUP_DIR, old))
            except Exception:
                pass
        log(f"Backup guardado: {backup_path}")
    except Exception as e:
        log(f"WARNING: Backup falló: {e}")


def _backup_loop() -> None:
    while True:
        time.sleep(BACKUP_INTERVAL_SEC)
        _do_backup()


def persist() -> None:
    with LOCK_STATE:
        save_json(STATE_PATH, STATE)


def load_state() -> None:
    global STATE
    data = load_json(STATE_PATH)
    if not data:
        STATE = json.loads(json.dumps(DEFAULT_STATE))
        persist()
        return
    merged = json.loads(json.dumps(DEFAULT_STATE))
    for k in ("users", "peers", "networks", "events"):
        merged[k] = data.get(k, merged[k])
    merged["version"] = data.get("version", merged["version"])
    merged["config_version"] = data.get("config_version", merged["config_version"])
    STATE = merged


def bump_config_version_locked() -> int:
    with LOCK_STATE:
        STATE["config_version"] = int(STATE.get("config_version", 1)) + 1
        return STATE["config_version"]


# =========================
# AUTO-APPROVE RULES
# =========================
def _parse_auto_approve_rules(raw: str) -> Dict[str, str]:
    out: Dict[str, str] = {}
    if not raw:
        return out
    for part in [x.strip() for x in raw.split("|") if x.strip()]:
        if ":" not in part:
            continue
        tag, net = part.split(":", 1)
        out[tag.strip()] = net.strip()
    return out


AUTO_APPROVE_RULES = _parse_auto_approve_rules(AUTO_APPROVE_RULES_RAW)


# =========================
# TENANT helpers
# =========================
def _peer_owner_from_metadata(metadata: Optional[Dict[str, Any]]) -> str:
    if not metadata:
        return "default"
    owner = metadata.get("owner") or metadata.get("user_id") or metadata.get("tenant")
    return str(owner).strip() if owner else "default"


def _enforce_tenant_for_peer(user_id: str, peer_id: str) -> None:
    with LOCK_PEERS:
        p = STATE["peers"].get(peer_id)
    if not p:
        raise KeyError("peer not found")
    if str(p.get("user_id") or "default") != str(user_id):
        raise PermissionError("cross-tenant forbidden")


def _filter_events_for_tenant(user_id: str) -> List[Dict[str, Any]]:
    out = []
    with LOCK_EVENTS:
        events = list(STATE.get("events") or [])
    for ev in events:
        d = ev.get("detail") or {}
        pid = d.get("peer_id")
        nid = d.get("network_id")
        try:
            if pid:
                with LOCK_PEERS:
                    p = STATE["peers"].get(pid) or {}
                if str(p.get("user_id") or "default") != str(user_id):
                    continue
            if nid:
                with LOCK_NETWORKS:
                    n = STATE["networks"].get(nid) or {}
                if str(n.get("user_id") or "") != str(user_id):
                    continue
        except Exception:
            continue
        out.append(ev)
    return out


# =========================
# USERS
# =========================
def _user_exists(user_id: str) -> bool:
    with LOCK_USERS:
        return user_id in (STATE.get("users") or {})


def _get_user(user_id: str) -> Dict[str, Any]:
    with LOCK_USERS:
        u = (STATE.get("users") or {}).get(user_id)
    if not u:
        raise KeyError("user not found")
    return u


def _issue_user_token(user_id: str) -> str:
    tok = "u_" + secrets.token_hex(16)
    with LOCK_USERS:
        users = STATE.get("users") or {}
        u = users.get(user_id) or {"created_ts": now_ts(), "disabled": False}
        u["token"] = tok
        u.setdefault("created_ts", now_ts())
        users[user_id] = u
        STATE["users"] = users
    return tok


def _check_user_token(user_id: str, token: str) -> None:
    u = _get_user(user_id)
    if u.get("disabled"):
        raise PermissionError("user disabled")
    if str(u.get("token") or "") != str(token):
        raise PermissionError("invalid user token")


# =========================
# ESC-03: Quotas por tenant
# =========================
def _get_tenant_quota(user_id: str) -> Dict[str, int]:
    with LOCK_USERS:
        u = (STATE.get("users") or {}).get(user_id) or {}
    return {
        "max_peers": int(u.get("max_peers", DEFAULT_MAX_PEERS)),
        "max_networks": int(u.get("max_networks", DEFAULT_MAX_NETWORKS)),
    }


def _check_peer_quota(user_id: str) -> None:
    quota = _get_tenant_quota(user_id)
    with LOCK_PEERS:
        count = sum(1 for p in STATE["peers"].values()
                    if str(p.get("user_id") or "default") == str(user_id))
    if count >= quota["max_peers"]:
        raise PermissionError(f"Peer quota exceeded: {count}/{quota['max_peers']} for user '{user_id}'")


def _check_network_quota(user_id: str) -> None:
    quota = _get_tenant_quota(user_id)
    with LOCK_NETWORKS:
        count = sum(1 for n in STATE["networks"].values()
                    if str(n.get("user_id") or "") == str(user_id))
    if count >= quota["max_networks"]:
        raise PermissionError(f"Network quota exceeded: {count}/{quota['max_networks']} for user '{user_id}'")


# =========================
# NETWORK HELPERS / ALLOC
# =========================
def _ensure_network_alloc_struct(n: Dict[str, Any]) -> None:
    if "alloc" not in n or not isinstance(n["alloc"], dict):
        n["alloc"] = {"reserved": [], "assigned": {}}
    n["alloc"].setdefault("reserved", [])
    n["alloc"].setdefault("assigned", {})


def _alloc_ip_from_cidr(cidr: str, reserved: set, used: set) -> str:
    net = ipaddress.IPv4Network(cidr, strict=True)
    hosts = list(net.hosts())
    if len(hosts) < 3:
        raise RuntimeError("CIDR demasiado pequeño (mínimo /29)")
    for ip in hosts:
        ip_s = str(ip)
        if ip_s in reserved or ip_s in used:
            continue
        if ip_s.endswith(".1"):
            continue
        return ip_s
    raise RuntimeError("No hay IPs libres en el CIDR")


def _network_alloc_ip(network_id: str, peer_id: str) -> str:
    with LOCK_NETWORKS:
        n = STATE["networks"].get(network_id)
        if not n:
            raise KeyError("network not found")
        _ensure_network_alloc_struct(n)
        assigned = n["alloc"]["assigned"]
        if peer_id in assigned:
            return assigned[peer_id]
        reserved = set(n["alloc"]["reserved"] or [])
        used = set(assigned.values())
        ip_s = _alloc_ip_from_cidr(n["tunnel_cidr"], reserved, used)
        assigned[peer_id] = ip_s
        n["alloc"]["assigned"] = assigned
        STATE["networks"][network_id] = n
    return ip_s


def _network_release_ip(network_id: str, peer_id: str) -> None:
    """EST-02: Devuelve la IP del peer al pool."""
    with LOCK_NETWORKS:
        n = STATE["networks"].get(network_id)
        if not n:
            return
        _ensure_network_alloc_struct(n)
        released = n["alloc"]["assigned"].pop(peer_id, None)
        if released:
            STATE["networks"][network_id] = n
            log(f"IP {released} devuelta al pool de red '{network_id}'")


def _peer_all_allowed_ips(peer_id: str) -> List[str]:
    with LOCK_PEERS:
        p = STATE["peers"].get(peer_id)
    if not p:
        raise KeyError("peer not found")
    out: List[str] = []
    for info in (p.get("networks") or {}).values():
        if info.get("ip"):
            out.append(WG_PEER_ALLOWED_FMT.format(ip=info["ip"]))
    for adv in (p.get("advertised_networks") or []):
        if adv.get("cidr"):
            out.append(adv["cidr"])
    seen, uniq = set(), []
    for x in out:
        if x not in seen:
            seen.add(x)
            uniq.append(x)
    return uniq


def _hub_apply_peer_allowed_ips(peer_id: str) -> None:
    with LOCK_PEERS:
        p = STATE["peers"].get(peer_id)
    if not p:
        raise KeyError("peer not found")
    pub = p.get("public_key")
    if not pub:
        raise ValueError("peer has no public_key")
    allowed = _peer_all_allowed_ips(peer_id)
    if not allowed:
        raise ValueError("peer has no assigned IPs/routes")
    hub_apply_peer(pub, ",".join(allowed))


def _ensure_default_network() -> None:
    with LOCK_NETWORKS:
        if DEFAULT_NET_ID in STATE["networks"]:
            return
        first_host = str(list(ipaddress.IPv4Network(DEFAULT_NET_CIDR).hosts())[0])
        STATE["networks"][DEFAULT_NET_ID] = {
            "network_id": DEFAULT_NET_ID,
            "name": DEFAULT_NET_ID,
            "tunnel_cidr": DEFAULT_NET_CIDR,
            "topology": "hub-spoke",   # F1: la red default es siempre hub-spoke
            "hub_peer_id": "HUB",
            "user_id": None,
            "created_ts": now_ts(),
            "mesh_keepalive": MESH_DEFAULT_KEEPALIVE,
            "alloc": {"reserved": [first_host], "assigned": {}},
        }
    add_event("network.create.auto", {"network_id": DEFAULT_NET_ID, "cidr": DEFAULT_NET_CIDR})


def _auto_approve_if_allowed(peer_id: str, requested_network_id: str) -> Dict[str, Any]:
    if not AUTO_APPROVE_ENABLED:
        return {"auto_approved": False, "reason": "disabled"}
    with LOCK_PEERS:
        p = STATE["peers"].get(peer_id)
    if not p:
        return {"auto_approved": False, "reason": "peer_not_found"}
    tags = set(p.get("tags") or [])
    matched_tag = next((t for t in tags if AUTO_APPROVE_RULES.get(t) == requested_network_id), None)
    if not matched_tag:
        return {"auto_approved": False, "reason": "no_matching_tag_rule"}

    # MT-02: bloquear si se requiere confirmación manual
    if AUTO_APPROVE_REQUIRE_CONFIRM:
        add_event("peer.auto_approve.pending_confirm", {
            "peer_id": peer_id, "network_id": requested_network_id, "matched_tag": matched_tag,
        })
        return {"auto_approved": False, "reason": "requires_manual_confirm", "matched_tag": matched_tag}

    ip_s = _network_alloc_ip(requested_network_id, peer_id)
    with LOCK_PEERS:
        p = STATE["peers"].get(peer_id) or {}
        nets = p.get("networks") or {}
        nets[requested_network_id] = {"ip": ip_s}
        p["networks"] = nets
        p["pending_network_requests"] = [x for x in (p.get("pending_network_requests") or [])
                                          if x != requested_network_id]
        STATE["peers"][peer_id] = p
    _hub_apply_peer_allowed_ips(peer_id)
    bump_config_version_locked()
    persist()
    # MT-02: log de auditoría explícito
    add_event("peer.auto_assign_network", {
        "peer_id": peer_id, "network_id": requested_network_id,
        "ip": ip_s, "matched_tag": matched_tag, "auto_approve": True,
    })
    log(f"AUTO-APPROVE: peer='{peer_id}' network='{requested_network_id}' ip={ip_s} tag='{matched_tag}'")
    return {"auto_approved": True, "network_id": requested_network_id, "ip": ip_s, "matched_tag": matched_tag}


# =========================
# ESC-02: ThreadingMixIn XML-RPC
# =========================
class ThreadingXMLRPCServer(ThreadingMixIn, SimpleXMLRPCServer):
    daemon_threads = True


class Handler(SimpleXMLRPCRequestHandler):
    rpc_paths = ("/RPC2",)


# =========================
# AUTH endpoints
# =========================
def auth_login(user_id: str, peer_id: Optional[str], user_token: str,
               scopes: Optional[List[str]] = None, ttl_seconds: Optional[int] = None) -> Dict[str, Any]:
    if not user_id or not user_token:
        raise ValueError("user_id and user_token required")
    scopes = scopes or ["*"]
    ttl = int(ttl_seconds) if ttl_seconds is not None else JWT_TTL_DEFAULT
    _check_user_token(user_id, user_token)
    tok, exp = _jwt_encode({
        "role": "user", "user_id": user_id,
        "peer_id": str(peer_id).strip() if peer_id else None,
        "scopes": scopes,
    }, ttl)
    return {"jwt": tok, "expires_at": exp}


def auth_refresh(jwt_token: str, ttl_seconds: Optional[int] = None) -> Dict[str, Any]:
    if not jwt_token:
        raise ValueError("jwt_token required")
    payload = _jwt_decode(jwt_token)
    jti = str(payload.get("jti") or "")
    if jti and _is_revoked_jti(jti):
        raise PermissionError("jwt revoked")
    ttl = int(ttl_seconds) if ttl_seconds is not None else JWT_TTL_DEFAULT
    tok, exp = _jwt_encode({
        "role": payload.get("role", "user"), "user_id": payload.get("user_id"),
        "peer_id": payload.get("peer_id"), "scopes": payload.get("scopes") or [],
    }, ttl)
    return {"jwt": tok, "expires_at": exp}


def auth_whoami(jwt_token: str) -> Dict[str, Any]:
    p = _jwt_decode(jwt_token)
    for k in ("iat", "nbf", "exp"):
        p.pop(k, None)
    return p


# =========================
# orch.*
# =========================
def orch_health(token: Optional[str] = None) -> str:
    if token is not None:
        mode, _, _, _ = _auth_from_token(token)
        if mode != "jwt":
            raise PermissionError("authentication required: provide a valid JWT")
    return "ok"


def orch_metrics(token: Optional[str] = None) -> Dict[str, Any]:
    mode, uid, scopes, is_admin_jwt = _auth_from_token(token)
    now = now_ts()
    with LOCK_PEERS:
        total = len(STATE["peers"])
        alive = sum(1 for p in STATE["peers"].values()
                    if p.get("last_heartbeat_ts") and
                    (now - int(p["last_heartbeat_ts"])) <= HEARTBEAT_TTL_SEC)
    base = {
        "ts": now, "config_version": STATE.get("config_version", 1),
        "hub_agent_url": HUB_AGENT_URL, "hub_endpoint": HUB_ENDPOINT,
        "auto_approve_enabled": AUTO_APPROVE_ENABLED, "auto_approve_rules": AUTO_APPROVE_RULES,
    }
    if (mode == "legacy" and token == ADMIN_TOKEN) or is_admin_jwt:
        with LOCK_USERS:
            users_total = len(STATE.get("users") or {})
        with LOCK_NETWORKS:
            networks_total = len(STATE.get("networks") or {})
        base.update({"peers_total": total, "peers_alive": alive, "peers_stale": total - alive,
                     "users_total": users_total, "networks_total": networks_total})
        return base
    if mode == "jwt":
        _require_scope(scopes, "orch:read")
        uid_s = str(uid or "")
        with LOCK_PEERS:
            peers_t = [p for p in STATE["peers"].values()
                       if str(p.get("user_id") or "default") == uid_s]
            alive_t = sum(1 for p in peers_t
                          if p.get("last_heartbeat_ts") and
                          (now - int(p["last_heartbeat_ts"])) <= HEARTBEAT_TTL_SEC)
        base.update({"user_id": uid_s, "peers_total": len(peers_t),
                     "peers_alive": alive_t, "peers_stale": len(peers_t) - alive_t})
        return base
    raise PermissionError("authentication required: provide a valid JWT")


def orch_events(token: Optional[str] = None) -> List[Dict[str, Any]]:
    mode, uid, scopes, is_admin_jwt = _auth_from_token(token)
    if (mode == "legacy" and token == ADMIN_TOKEN) or is_admin_jwt:
        with LOCK_EVENTS:
            return list(STATE.get("events") or [])
    if mode == "jwt":
        _require_scope(scopes, "orch:read")
        return _filter_events_for_tenant(str(uid))  # MT-03
    raise PermissionError("authentication required: provide a valid JWT")


def orch_revoke(jti: str, admin_token: Optional[str] = None) -> bool:
    orch_check_admin_token(admin_token)
    _revoke_jti(str(jti), "admin_revoke")
    add_event("orch.revoke", {"jti": str(jti)})
    return True


# =========================
# orch.user-*
# =========================
def orch_user_create(user_id: str, admin_token: Optional[str] = None) -> Dict[str, Any]:
    orch_check_admin_token(admin_token)
    if not user_id:
        raise ValueError("user_id required")
    user_id = str(user_id).strip()
    if _user_exists(user_id):
        raise ValueError("user already exists")
    tok = _issue_user_token(user_id)
    persist()
    add_event("user.create", {"user_id": user_id})
    return {"user_id": user_id, "token": tok}


def orch_user_list(admin_token: Optional[str] = None) -> List[Dict[str, Any]]:
    orch_check_admin_token(admin_token)
    with LOCK_USERS:
        out = [{"user_id": uid, "created_ts": u.get("created_ts"), "disabled": bool(u.get("disabled"))}
               for uid, u in (STATE.get("users") or {}).items()]
    return sorted(out, key=lambda x: x["user_id"])


def orch_user_get(user_id: str, admin_token: Optional[str] = None) -> Dict[str, Any]:
    orch_check_admin_token(admin_token)
    u = _get_user(user_id)
    return {"user_id": user_id, **u}


def orch_user_delete(user_id: str, purge: bool = False, admin_token: Optional[str] = None) -> bool:
    orch_check_admin_token(admin_token)
    with LOCK_USERS:
        (STATE.get("users") or {}).pop(user_id, None)
    if purge:
        with LOCK_PEERS:
            to_remove = [pid for pid, p in STATE.get("peers", {}).items()
                         if str(p.get("user_id") or "") == str(user_id)]
        for pid in to_remove:
            with LOCK_PEERS:
                p = STATE["peers"].get(pid) or {}
            if p.get("public_key"):
                try:
                    hub_remove_peer(p["public_key"])
                except Exception:
                    pass
            for nid in list((p.get("networks") or {}).keys()):
                _network_release_ip(nid, pid)  # EST-02
            with LOCK_PEERS:
                STATE["peers"].pop(pid, None)
        with LOCK_NETWORKS:
            for nid in [k for k, n in list(STATE.get("networks", {}).items())
                        if str(n.get("user_id") or "") == str(user_id) and k != DEFAULT_NET_ID]:
                STATE["networks"].pop(nid, None)
    bump_config_version_locked()
    persist()
    add_event("user.delete", {"user_id": user_id, "purge": bool(purge)})
    return True


def orch_issue_user_token(user_id: str, admin_token: Optional[str] = None) -> Dict[str, Any]:
    orch_check_admin_token(admin_token)
    if not _user_exists(user_id):
        raise KeyError("user not found")
    tok = _issue_user_token(user_id)
    persist()
    add_event("user.issue_token", {"user_id": user_id})
    return {"user_id": user_id, "token": tok}


# =========================
# network.*
# =========================
def network_create(name: str, tunnel_cidr: str, topology: str, hub_peer_id: str,
                   user_id: Optional[str] = None, admin_token: Optional[str] = None,
                   mesh_keepalive: Optional[int] = None,
                   hub_mesh_relay_fallback_cidr: Optional[str] = None) -> str:  # HM-F1a
    orch_check_admin_token(admin_token)
    if not name:
        raise ValueError("name required")
    # F1: validar enum de topología
    topology = str(topology or "hub-spoke").strip()
    if topology not in VALID_TOPOLOGIES:
        raise ValueError(f"topology inválida: '{topology}'. Valores válidos: {sorted(VALID_TOPOLOGIES)}")
    user_id = str(user_id).strip() if user_id else None
    if user_id:
        _check_network_quota(user_id)  # ESC-03
    with LOCK_NETWORKS:
        network_id = str(name).strip()
        if network_id in STATE["networks"]:
            raise ValueError("network already exists")
        net = ipaddress.IPv4Network(tunnel_cidr, strict=True)
        first_host = str(list(net.hosts())[0]) if list(net.hosts()) else None
        # HM-F1a: validar hub_mesh_relay_fallback_cidr si se proporciona
        relay_cidr = None
        if hub_mesh_relay_fallback_cidr:
            try:
                ipaddress.IPv4Network(hub_mesh_relay_fallback_cidr, strict=False)
                relay_cidr = hub_mesh_relay_fallback_cidr
            except ValueError as e:
                raise ValueError(f"hub_mesh_relay_fallback_cidr inválido: {e}")
        STATE["networks"][network_id] = {
            "network_id": network_id, "name": name, "tunnel_cidr": tunnel_cidr,
            "topology": topology, "hub_peer_id": hub_peer_id, "user_id": user_id,
            "created_ts": now_ts(),
            # F1: keepalive específico para peers mesh de esta red
            "mesh_keepalive": int(mesh_keepalive) if mesh_keepalive else MESH_DEFAULT_KEEPALIVE,
            # HM-F1a: CIDR que el HUB anuncia como relay en hub-mesh (None = usar tunnel_cidr)
            "hub_mesh_relay_fallback_cidr": relay_cidr,
            "alloc": {"reserved": [first_host] if first_host else [], "assigned": {}},
        }
    bump_config_version_locked()
    persist()
    add_event("network.create", {"network_id": network_id, "cidr": tunnel_cidr, "user_id": user_id})
    return network_id


def network_delete(network_id: str, purge: bool = False, admin_token: Optional[str] = None) -> bool:
    orch_check_admin_token(admin_token)
    if network_id == DEFAULT_NET_ID:
        raise ValueError("cannot delete default network")
    if purge:
        with LOCK_PEERS:
            for pid, p in list(STATE.get("peers", {}).items()):
                nets = p.get("networks") or {}
                if network_id in nets:
                    nets.pop(network_id, None)
                    p["networks"] = nets
                    STATE["peers"][pid] = p
                    try:
                        _hub_apply_peer_allowed_ips(pid)
                    except Exception:
                        pass
    with LOCK_NETWORKS:
        STATE["networks"].pop(network_id, None)
    bump_config_version_locked()
    persist()
    add_event("network.delete", {"network_id": network_id, "purge": bool(purge)})
    return True


def network_list(user_id: Optional[str] = None, admin_token: Optional[str] = None,
                 token: Optional[str] = None) -> List[Dict[str, Any]]:
    mode, uid, scopes, is_admin_jwt = _auth_from_token(token)
    with LOCK_NETWORKS:
        nets = dict(STATE.get("networks") or {})
    if admin_token:
        orch_check_admin_token(admin_token)
        if user_id:
            return [{"network_id": nid, **n} for nid, n in nets.items()
                    if str(n.get("user_id") or "") == str(user_id)]
        return [{"network_id": nid, **n} for nid, n in nets.items()]
    if mode == "jwt":
        _require_scope(scopes, "network:read")
        uid_s = str(uid)
        return [{"network_id": nid, **n} for nid, n in nets.items()
                if str(n.get("user_id") or "") == uid_s]
    raise PermissionError("authentication required: provide a valid JWT")


def network_get(network_id: str, admin_token: Optional[str] = None, token: Optional[str] = None) -> Dict[str, Any]:
    mode, uid, scopes, _ = _auth_from_token(token)
    with LOCK_NETWORKS:
        n = STATE["networks"].get(network_id)
    if not n:
        raise KeyError("network not found")
    if admin_token:
        orch_check_admin_token(admin_token)
        return dict(n)
    if mode == "jwt":
        _require_scope(scopes, "network:read")
        if str(n.get("user_id") or "") != str(uid):
            raise PermissionError("cross-tenant forbidden")
        return dict(n)
    raise PermissionError("authentication required: provide a valid JWT")


def network_get_topology(network_id: str, admin_token: Optional[str] = None, token: Optional[str] = None) -> Dict[str, Any]:
    mode, uid, scopes, _ = _auth_from_token(token)
    with LOCK_NETWORKS:
        n = STATE["networks"].get(network_id)
    if not n:
        raise KeyError("network not found")
    if admin_token:
        orch_check_admin_token(admin_token)
    elif mode == "jwt":
        _require_scope(scopes, "network:read")
        if str(n.get("user_id") or "") != str(uid):
            raise PermissionError("cross-tenant forbidden")
    else:
        raise PermissionError("authentication required: provide a valid JWT")
    assigned = (n.get("alloc") or {}).get("assigned") or {}
    peers_info = {}
    with LOCK_PEERS:
        for pid, ip_s in assigned.items():
            p = STATE["peers"].get(pid) or {}
            peers_info[pid] = {
                "tunnel_ip": ip_s, "endpoint": p.get("endpoint"),
                "tags": p.get("tags", []), "user_id": p.get("user_id"),
            }
    return {"network_id": network_id, **n, "peers": peers_info}


def network_alloc_ip(network_id: str, peer_id: str, admin_token: Optional[str] = None, token: Optional[str] = None) -> Dict[str, Any]:
    mode, uid, scopes, _ = _auth_from_token(token)
    with LOCK_NETWORKS:
        n = STATE["networks"].get(network_id)
    if not n:
        raise KeyError("network not found")
    if admin_token:
        orch_check_admin_token(admin_token)
    elif mode == "jwt":
        _require_scope(scopes, "network:write")
        if str(n.get("user_id") or "") != str(uid):
            raise PermissionError("cross-tenant forbidden")
        _enforce_tenant_for_peer(str(uid), peer_id)
    else:
        raise PermissionError("authentication required: provide a valid JWT")
    with LOCK_PEERS:
        p = STATE["peers"].get(peer_id)
    if not p:
        raise KeyError("peer not registered")
    ip_s = _network_alloc_ip(network_id, peer_id)
    persist()
    add_event("network.alloc_ip", {"network_id": network_id, "peer_id": peer_id, "ip": ip_s})
    return {"network_id": network_id, "peer_id": peer_id, "ip": ip_s}


# =========================
# peer.*
# =========================
def peer_register(name: str, public_key: str, endpoint: Optional[str], tags: Optional[List[str]],
                  metadata: Optional[Dict[str, Any]], token: Optional[str] = None) -> Dict[str, Any]:
    if not name or not public_key:
        raise ValueError("name and public_key required")
    tags = tags or []
    metadata = metadata or {}
    owner_from_meta = _peer_owner_from_metadata(metadata)
    mode, uid, scopes, _ = _auth_from_token(token)
    if mode == "jwt":
        _require_scope(scopes, "peer:register")
        if owner_from_meta != str(uid):
            raise PermissionError("owner mismatch with jwt user_id")
    else:
        raise PermissionError("authentication required: provide a valid JWT")

    _ensure_default_network()
    peer_id = str(name).strip()
    user_id = str(uid) if mode == "jwt" else owner_from_meta

    with LOCK_PEERS:
        is_new = peer_id not in STATE["peers"]
    if is_new:
        _check_peer_quota(user_id)  # ESC-03

    with LOCK_PEERS:
        existing = STATE["peers"].get(peer_id) or {}
    nets = existing.get("networks") or {}
    if DEFAULT_NET_ID not in nets:
        nets[DEFAULT_NET_ID] = {"ip": _network_alloc_ip(DEFAULT_NET_ID, peer_id)}

    rec = {
        "peer_id": peer_id, "name": name, "user_id": user_id,
        "public_key": public_key, "endpoint": endpoint, "tags": tags, "metadata": metadata,
        # F1: puerto WireGuard local del peer (útil para construcción de endpoint en mesh)
        "mesh_listen_port": int(metadata.get("mesh_listen_port")) if metadata.get("mesh_listen_port") else None,
        # HM-F1b: clasificación NAT y preferencia de relay para hub-mesh
        "nat_type":   metadata.get("nat_type"),           # 'none'|'full-cone'|'symmetric'|None
        "relay_mode": metadata.get("relay_mode", "auto"), # 'auto'|'force_direct'|'force_relay'
        # Mapa {other_peer_id: 'direct'|'hub-relay'|'unknown'} — actualizado por peer.report_reachability
        "reachability_map":         (existing.get("reachability_map") or {}),
        "last_direct_handshake_ts": existing.get("last_direct_handshake_ts"),
        "networks": nets,
        "pending_network_requests": existing.get("pending_network_requests") or [],
        "advertised_networks": existing.get("advertised_networks") or [],
        "registered_ts": now_ts(),
        "last_heartbeat_ts": existing.get("last_heartbeat_ts"),
        "status": existing.get("status") or {},
        "desired_config_version": STATE.get("config_version", 1),
    }
    with LOCK_PEERS:
        STATE["peers"][peer_id] = rec
    _hub_apply_peer_allowed_ips(peer_id)
    bump_config_version_locked()
    persist()
    add_event("peer.register", {"peer_id": peer_id, "endpoint": endpoint, "user_id": user_id, "net": DEFAULT_NET_ID})
    hub_pub = hub_public_key()
    with LOCK_PEERS:
        primary_ip = STATE["peers"][peer_id]["networks"][DEFAULT_NET_ID]["ip"]
    return {
        "peer_id": peer_id, "wg_ip": f"{primary_ip}/32",
        "hub_endpoint": HUB_ENDPOINT, "hub_public_key": hub_pub,
        "config_version": STATE["config_version"],
    }


def peer_heartbeat(peer_id: str, status: Dict[str, Any], token: Optional[str] = None) -> Dict[str, Any]:
    mode, uid, scopes, _ = _auth_from_token(token)
    if mode == "jwt":
        _require_scope(scopes, "peer:heartbeat")
        _enforce_tenant_for_peer(str(uid), peer_id)
    else:
        raise PermissionError("authentication required: provide a valid JWT")
    with LOCK_PEERS:
        p = STATE["peers"].get(peer_id)
        if not p:
            raise KeyError("peer not registered")
        p["last_heartbeat_ts"] = now_ts()
        p["status"] = status or {}
        p["desired_config_version"] = STATE.get("config_version", 1)

        # F1: si el endpoint cambió, notificar a todos los peers de sus redes mesh
        new_endpoint = (status or {}).get("endpoint")
        if new_endpoint and new_endpoint != p.get("endpoint"):
            old_ep = p.get("endpoint")
            p["endpoint"] = new_endpoint
            STATE["peers"][peer_id] = p
            # Liberar lock antes de bump (evitar deadlock con LOCK_STATE)
            _endpoint_changed = True
        else:
            _endpoint_changed = False
            STATE["peers"][peer_id] = p

        # HM-F2a: capturar cambio de nat_type para bump posterior
        new_nat_type = (status or {}).get("nat_type")
        _nat_changed = bool(
            new_nat_type and new_nat_type != p.get("nat_type")
        )
        if _nat_changed:
            p["nat_type"] = new_nat_type
            STATE["peers"][peer_id] = p

    if _endpoint_changed:
        bump_config_version_locked()
        add_event("peer.endpoint_updated", {
            "peer_id": peer_id, "endpoint": new_endpoint,
        })
        log(f"Endpoint de '{peer_id}' actualizado → {new_endpoint} (config_version bumped)")

    # HM-F2a: si nat_type cambió, bump solo si el peer tiene redes hub-mesh
    if _nat_changed and not _endpoint_changed:
        with LOCK_PEERS:
            p_nets = (STATE["peers"].get(peer_id) or {}).get("networks") or {}
        with LOCK_NETWORKS:
            has_hub_mesh = any(
                (STATE["networks"].get(nid) or {}).get("topology") == "hub-mesh"
                for nid in p_nets
            )
        if has_hub_mesh:
            bump_config_version_locked()
            add_event("peer.nat_type_updated", {"peer_id": peer_id, "nat_type": new_nat_type})
            log(f"nat_type de '{peer_id}' actualizado → {new_nat_type} (config_version bumped)")
    persist()
    return {"desired_config_version": STATE.get("config_version", 1)}


def peer_get_status(peer_id: str, token: Optional[str] = None) -> Dict[str, Any]:
    mode, uid, scopes, _ = _auth_from_token(token)
    if mode == "jwt":
        _require_scope(scopes, "peer:read")
        _enforce_tenant_for_peer(str(uid), peer_id)
    else:
        raise PermissionError("authentication required: provide a valid JWT")
    with LOCK_PEERS:
        p = STATE["peers"].get(peer_id)
    if not p:
        raise KeyError("peer not found")
    return p


def peer_update(peer_id: str, fields: Dict[str, Any], token: Optional[str] = None) -> bool:
    mode, uid, scopes, _ = _auth_from_token(token)
    if mode == "jwt":
        _require_scope(scopes, "peer:update")
        _enforce_tenant_for_peer(str(uid), peer_id)
    else:
        raise PermissionError("authentication required: provide a valid JWT")
    with LOCK_PEERS:
        p = STATE["peers"].get(peer_id)
        if not p:
            raise KeyError("peer not found")
        for k in ("endpoint", "tags", "metadata"):
            if k in fields:
                p[k] = fields[k]
        if "allowed_ips" in fields:
            raise PermissionError("allowed_ips override is admin-only")
        STATE["peers"][peer_id] = p
    bump_config_version_locked()
    persist()
    add_event("peer.update", {"peer_id": peer_id, "fields": list(fields.keys())})
    return True


def peer_update_admin(peer_id: str, fields: Dict[str, Any], admin_token: Optional[str] = None) -> bool:
    orch_check_admin_token(admin_token)
    with LOCK_PEERS:
        p = STATE["peers"].get(peer_id)
        if not p:
            raise KeyError("peer not found")
        for k in ("endpoint", "tags", "metadata"):
            if k in fields:
                p[k] = fields[k]
        if "allowed_ips" in fields:
            hub_apply_peer(p["public_key"], str(fields["allowed_ips"]))
        STATE["peers"][peer_id] = p
    bump_config_version_locked()
    persist()
    add_event("peer.update.admin", {"peer_id": peer_id, "fields": list(fields.keys())})
    return True


def peer_unregister(peer_id: str, token: Optional[str] = None) -> bool:
    mode, uid, scopes, _ = _auth_from_token(token)
    if mode == "jwt":
        _require_scope(scopes, "peer:delete")
        _enforce_tenant_for_peer(str(uid), peer_id)
    else:
        raise PermissionError("authentication required: provide a valid JWT")
    with LOCK_PEERS:
        p = STATE["peers"].get(peer_id)
        if not p:
            return True
        pub = p.get("public_key")
        peer_nets = list((p.get("networks") or {}).keys())
    if pub:
        hub_remove_peer(pub)
    for nid in peer_nets:
        _network_release_ip(nid, peer_id)  # EST-02
    with LOCK_PEERS:
        STATE["peers"].pop(peer_id, None)
    bump_config_version_locked()
    persist()
    add_event("peer.unregister", {"peer_id": peer_id})
    return True


def peer_rotate_key(peer_id: str, new_public_key: str, token: Optional[str] = None) -> bool:
    mode, uid, scopes, _ = _auth_from_token(token)
    if mode == "jwt":
        _require_scope(scopes, "peer:rotate_key")
        _enforce_tenant_for_peer(str(uid), peer_id)
    else:
        raise PermissionError("authentication required: provide a valid JWT")
    with LOCK_PEERS:
        p = STATE["peers"].get(peer_id)
        if not p:
            raise KeyError("peer not found")
        old_pub = p.get("public_key")
    if old_pub:
        hub_remove_peer(old_pub)
    with LOCK_PEERS:
        p["public_key"] = new_public_key
        STATE["peers"][peer_id] = p
    _hub_apply_peer_allowed_ips(peer_id)
    bump_config_version_locked()
    persist()
    add_event("peer.rotate_key", {"peer_id": peer_id})
    return True


def peer_list(user_id: Optional[str] = None, admin_token: Optional[str] = None, token: Optional[str] = None) -> List[Dict[str, Any]]:
    mode, uid, scopes, _ = _auth_from_token(token)
    with LOCK_PEERS:
        peers = dict(STATE.get("peers") or {})
    if admin_token:
        orch_check_admin_token(admin_token)
        if user_id:
            return [p for p in peers.values() if str(p.get("user_id") or "") == str(user_id)]
        return list(peers.values())
    if mode == "jwt":
        _require_scope(scopes, "peer:read")
        uid_s = str(uid)
        return [p for p in peers.values() if str(p.get("user_id") or "") == uid_s]
    raise PermissionError("authentication required: provide a valid JWT")


def peer_get(peer_id: str, admin_token: Optional[str] = None, token: Optional[str] = None) -> Dict[str, Any]:
    with LOCK_PEERS:
        p = STATE.get("peers", {}).get(peer_id)
    if not p:
        raise KeyError("peer not found")
    if admin_token:
        orch_check_admin_token(admin_token)
        return p
    mode, uid, scopes, _ = _auth_from_token(token)
    if mode == "jwt":
        _require_scope(scopes, "peer:read")
        _enforce_tenant_for_peer(str(uid), peer_id)
        return p
    raise PermissionError("authentication required: provide a valid JWT")


def peer_request_network(peer_id: str, network_id: str, token: Optional[str] = None) -> Dict[str, Any]:
    mode, uid, scopes, _ = _auth_from_token(token)
    with LOCK_NETWORKS:
        if network_id not in STATE["networks"]:
            raise KeyError("network not found")
    with LOCK_PEERS:
        p = STATE["peers"].get(peer_id)
    if not p:
        raise KeyError("peer not registered")
    if mode == "jwt":
        _require_scope(scopes, "network:write")
        _enforce_tenant_for_peer(str(uid), peer_id)
        with LOCK_NETWORKS:
            if str((STATE["networks"].get(network_id) or {}).get("user_id") or "") != str(uid):
                raise PermissionError("cross-tenant forbidden")
    else:
        raise PermissionError("authentication required: provide a valid JWT")
    with LOCK_PEERS:
        if network_id in (p.get("networks") or {}):
            return {"requested": False, "reason": "already_member"}
        req = p.get("pending_network_requests") or []
        if network_id not in req:
            req.append(network_id)
        p["pending_network_requests"] = req
        STATE["peers"][peer_id] = p
    persist()
    add_event("peer.request_network", {"peer_id": peer_id, "network_id": network_id})
    res = _auto_approve_if_allowed(peer_id, network_id)
    return {"requested": True, "network_id": network_id, **res}


def peer_assign_network(peer_id: str, network_id: str, ip: str, role: Optional[str] = None,
                        admin_token: Optional[str] = None, token: Optional[str] = None) -> bool:
    orch_check_admin_token(admin_token)
    with LOCK_NETWORKS:
        n = STATE["networks"].get(network_id)
    if not n:
        raise KeyError("network not found")
    with LOCK_PEERS:
        p = STATE["peers"].get(peer_id)
    if not p:
        raise KeyError("peer not registered")
    if ipaddress.IPv4Address(ip) not in ipaddress.IPv4Network(n["tunnel_cidr"], strict=True):
        raise ValueError("ip not in network cidr")
    with LOCK_NETWORKS:
        _ensure_network_alloc_struct(n)
        for other, other_ip in n["alloc"]["assigned"].items():
            if other != peer_id and other_ip == ip:
                raise ValueError("ip already assigned")
        n["alloc"]["assigned"][peer_id] = ip
        STATE["networks"][network_id] = n
    with LOCK_PEERS:
        nets = p.get("networks") or {}
        nets[network_id] = {"ip": ip, "role": role}
        p["networks"] = nets
        p["pending_network_requests"] = [x for x in (p.get("pending_network_requests") or []) if x != network_id]
        STATE["peers"][peer_id] = p
    _hub_apply_peer_allowed_ips(peer_id)
    bump_config_version_locked()
    persist()
    add_event("peer.assign_network", {"peer_id": peer_id, "network_id": network_id, "ip": ip, "role": role})
    return True


def peer_remove_from_network(peer_id: str, network_id: str, admin_token: Optional[str] = None) -> bool:
    orch_check_admin_token(admin_token)
    with LOCK_PEERS:
        p = STATE["peers"].get(peer_id)
    if not p:
        raise KeyError("peer not registered")
    with LOCK_PEERS:
        nets = p.get("networks") or {}
        nets.pop(network_id, None)
        p["networks"] = nets
        STATE["peers"][peer_id] = p
    _network_release_ip(network_id, peer_id)  # EST-02
    _hub_apply_peer_allowed_ips(peer_id)
    bump_config_version_locked()
    persist()
    add_event("peer.remove_from_network", {"peer_id": peer_id, "network_id": network_id})
    return True


# =========================
# config.*
# =========================

# F2: helper — devuelve peers vivos de una red mesh, excluyendo al solicitante
def _get_alive_mesh_peers(requester_peer_id: str, network_id: str) -> List[Dict[str, Any]]:
    """
    Retorna la lista de peers activos en la red `network_id` excluyendo al solicitante.
    Un peer se considera vivo si su last_heartbeat_ts está dentro de HEARTBEAT_TTL_SEC.
    Limitado a MESH_MAX_PEERS entradas para evitar configs masivas.
    """
    now = now_ts()
    with LOCK_NETWORKS:
        n = STATE["networks"].get(network_id)
    if not n:
        return []
    assigned = (n.get("alloc") or {}).get("assigned") or {}
    result: List[Dict[str, Any]] = []
    with LOCK_PEERS:
        for pid, tunnel_ip in assigned.items():
            if pid == requester_peer_id:
                continue
            p = STATE["peers"].get(pid)
            if not p:
                continue
            last_hb = int(p.get("last_heartbeat_ts") or 0)
            alive = last_hb > 0 and (now - last_hb) <= HEARTBEAT_TTL_SEC
            result.append({
                "peer_id":    pid,
                "public_key": p.get("public_key") or "",
                "endpoint":   p.get("endpoint"),
                "tunnel_ip":  tunnel_ip,
                "alive":      alive,
                "last_seen_ts": last_hb,
            })
    # Ordenar: vivos primero, luego por peer_id para estabilidad
    result.sort(key=lambda x: (not x["alive"], x["peer_id"]))
    return result[:MESH_MAX_PEERS]


def _mesh_peers_hash(peers: List[Dict[str, Any]]) -> str:
    """SHA-256 de la lista de peers para que el cliente detecte cambios sin comparar todo."""
    canonical = json.dumps(
        [{"peer_id": p["peer_id"], "public_key": p["public_key"],
          "endpoint": p["endpoint"], "alive": p["alive"]} for p in peers],
        sort_keys=True
    )
    return hashlib.sha256(canonical.encode()).hexdigest()[:16]


# HM-F2b: helper — clasifica peers de una red hub-mesh en direct / relay_only
def _classify_peers_for_hub_mesh(
    requester_peer_id: str,
    network_id: str,
) -> Dict[str, Any]:
    """
    Clasifica los peers de la red hub-mesh en:
      direct     — alive + endpoint conocido + NAT no simétrico + sin fuerza-relay
      relay_only — alive pero no directamente alcanzable (NAT sim., sin endpoint, o force_relay)
    También devuelve:
      relay_cidr — CIDR que el HUB anuncia como fallback (hub_mesh_relay_fallback_cidr o tunnel_cidr)
    """
    now = now_ts()
    with LOCK_NETWORKS:
        n = STATE["networks"].get(network_id)
    if not n:
        return {"direct": [], "relay_only": [], "relay_cidr": "0.0.0.0/0"}
    assigned = (n.get("alloc") or {}).get("assigned") or {}
    relay_cidr = n.get("hub_mesh_relay_fallback_cidr") or n.get("tunnel_cidr", "0.0.0.0/0")

    direct: List[Dict[str, Any]] = []
    relay_only: List[Dict[str, Any]] = []

    with LOCK_PEERS:
        requester = STATE["peers"].get(requester_peer_id) or {}
        req_rm = requester.get("reachability_map") or {}

        for pid, tunnel_ip in assigned.items():
            if pid == requester_peer_id:
                continue
            p = STATE["peers"].get(pid)
            if not p:
                continue
            last_hb = int(p.get("last_heartbeat_ts") or 0)
            alive = last_hb > 0 and (now - last_hb) <= HEARTBEAT_TTL_SEC
            if not alive:
                continue  # peers muertos: no reciben bloque de ningún tipo

            nat_type    = p.get("nat_type")      # None|'none'|'full-cone'|'symmetric'
            relay_mode  = p.get("relay_mode", "auto")
            endpoint    = p.get("endpoint")
            # ¿El requester reportó previamente que no puede alcanzar a este peer directamente?
            req_reported_relay = req_rm.get(pid) == "hub-relay"

            rec = {
                "peer_id":    pid,
                "public_key": p.get("public_key") or "",
                "endpoint":   endpoint,
                "tunnel_ip":  tunnel_ip,
                "nat_type":   nat_type,
                "relay_mode": relay_mode,
                "alive":      True,
                "last_seen_ts": last_hb,
            }

            is_direct = (
                relay_mode != "force_relay"
                and bool(endpoint)
                and nat_type != "symmetric"
                and (relay_mode == "force_direct" or not req_reported_relay)
            )

            if is_direct:
                direct.append(rec)
            else:
                relay_only.append(rec)

    direct.sort(key=lambda x: x["peer_id"])
    relay_only.sort(key=lambda x: x["peer_id"])
    return {"direct": direct, "relay_only": relay_only, "relay_cidr": relay_cidr}


def _hub_mesh_peers_hash(classified: Dict[str, Any]) -> str:
    """Hash compacto del resultado de _classify_peers_for_hub_mesh para detección de cambios."""
    canonical = json.dumps(
        {
            "direct":     [{"peer_id": p["peer_id"], "endpoint": p["endpoint"]} for p in classified["direct"]],
            "relay_only": [{"peer_id": p["peer_id"]} for p in classified["relay_only"]],
        },
        sort_keys=True
    )
    return hashlib.sha256(canonical.encode()).hexdigest()[:16]


def config_get_peer_config(peer_id: str, token: Optional[str] = None) -> Dict[str, Any]:
    mode, uid, scopes, _ = _auth_from_token(token)
    if mode == "jwt":
        _require_scope(scopes, "config:read")
        _enforce_tenant_for_peer(str(uid), peer_id)
    else:
        raise PermissionError("authentication required: provide a valid JWT")
    with LOCK_PEERS:
        p = STATE["peers"].get(peer_id)
    if not p:
        raise KeyError("peer not found")
    hub_pub = hub_public_key()
    nets = p.get("networks") or {}
    if not nets:
        raise ValueError("peer has no networks assigned")
    addresses = [f"{info['ip']}/32" for info in nets.values() if info.get("ip")]

    # F2 / HM-F3a: determinar topología de la red principal del peer
    primary_net_id = next(iter(nets.keys()))
    with LOCK_NETWORKS:
        primary_net = STATE["networks"].get(primary_net_id) or {}
    topology = primary_net.get("topology", "hub-spoke")

    # AllowedIPs del HUB depende de la topología
    with LOCK_NETWORKS:
        allowed_cidrs = [STATE["networks"][nid]["tunnel_cidr"]
                         for nid in nets if nid in STATE["networks"]]

    keepalive = primary_net.get("mesh_keepalive", MESH_DEFAULT_KEEPALIVE)

    # HM-F3a: en hub-mesh el HUB anuncia el CIDR completo (relay de fallback)
    if topology == "hub-mesh":
        hub_allowed_ips = primary_net.get("hub_mesh_relay_fallback_cidr") or \
                          primary_net.get("tunnel_cidr") or \
                          ",".join(sorted(set(allowed_cidrs)))
    else:
        hub_allowed_ips = ",".join(sorted(set(allowed_cidrs)))

    base = {
        "interface": {"address": ",".join(addresses), "mtu": int(os.getenv("WG_MTU", "1420"))},
        "peer": {
            "public_key": hub_pub,
            "endpoint": HUB_ENDPOINT,
            "allowed_ips": hub_allowed_ips,
            "persistent_keepalive": keepalive,
        },
        "meta": {
            "peer_id": peer_id,
            "user_id": p.get("user_id"),
            "networks": nets,
            "topology": topology,
            "config_version": STATE.get("config_version", 1),
        },
    }

    # F2: inyectar mesh_peers cuando la red es mesh puro
    if topology == "mesh":
        mesh_peers = _get_alive_mesh_peers(peer_id, primary_net_id)
        base["mesh_peers"] = mesh_peers
        base["meta"]["mesh_peers_hash"] = _mesh_peers_hash(mesh_peers)
        base["meta"]["mesh_network_id"] = primary_net_id

    # HM-F3a: inyectar clasificación hub-mesh cuando la red es hub-mesh
    elif topology == "hub-mesh":
        classified = _classify_peers_for_hub_mesh(peer_id, primary_net_id)
        base["hub_mesh_direct_peers"] = classified["direct"]
        base["hub_mesh_relay_peers"]  = classified["relay_only"]
        base["meta"]["hub_mesh_peers_hash"] = _hub_mesh_peers_hash(classified)
        base["meta"]["mesh_peers_hash"]     = base["meta"]["hub_mesh_peers_hash"]  # compat v3
        base["meta"]["mesh_network_id"]     = primary_net_id

    return base


def config_get_config_diff(peer_id: str, from_version: int, token: Optional[str] = None) -> Dict[str, Any]:
    cur = int(STATE.get("config_version", 1))
    if int(from_version) >= cur:
        return {"changed": False, "config_version": cur, "diff": {}}
    return {"changed": True, "config_version": cur, "diff": {"full": config_get_peer_config(peer_id, token=token)}}


# F2: endpoint — devuelve la lista de peers mesh para un peer solicitante
def config_get_mesh_peers(peer_id: str, network_id: str, token: Optional[str] = None):
    """
    RPC: config.get_mesh_peers(peer_id, network_id, token)
    - topology='mesh':      devuelve lista plana de peers vivos (v3, sin cambios)
    - topology='hub-mesh':  devuelve dict con 'direct', 'relay_only', 'relay_cidr'  (HM-F3b)
    """
    mode, uid, scopes, is_admin_jwt = _auth_from_token(token)
    if mode == "jwt":
        _require_scope(scopes, "config:read")
        _enforce_tenant_for_peer(str(uid), peer_id)
    else:
        raise PermissionError("authentication required: provide a valid JWT")

    with LOCK_NETWORKS:
        n = STATE["networks"].get(network_id)
    if not n:
        raise KeyError("network not found")
    topo = n.get("topology", "hub-spoke")
    if topo not in ("mesh", "hub-mesh"):
        raise ValueError(f"La red '{network_id}' tiene topología '{topo}', no 'mesh' ni 'hub-mesh'")

    if topo == "hub-mesh":
        return _classify_peers_for_hub_mesh(peer_id, network_id)  # HM-F3b
    return _get_alive_mesh_peers(peer_id, network_id)  # mesh puro — sin cambios


# HM-F2c: nuevo endpoint — un peer reporta si pudo (o perdió) handshake directo con otro
def peer_report_reachability(
    peer_id: str,
    target_peer_id: str,
    reachable: bool,
    token: Optional[str] = None,
) -> Dict[str, Any]:
    """
    RPC: peer.report_reachability(peer_id, target_peer_id, reachable, token)

    Actualiza reachability_map[peer_id] en el registro del target.
    Si el estado cambió → bump config_version para que target actualice su .conf.
    """
    mode, uid, scopes, _ = _auth_from_token(token)
    if mode == "jwt":
        _require_scope(scopes, "peer:heartbeat")
        _enforce_tenant_for_peer(str(uid), peer_id)
    else:
        raise PermissionError("authentication required: provide a valid JWT")

    new_state = "direct" if reachable else "hub-relay"
    _changed = False

    with LOCK_PEERS:
        if peer_id not in STATE["peers"]:
            raise KeyError(f"peer '{peer_id}' not registered")
        target = STATE["peers"].get(target_peer_id)
        if not target:
            raise KeyError(f"target peer '{target_peer_id}' not registered")
        rm = dict(target.get("reachability_map") or {})
        _changed = rm.get(peer_id) != new_state
        rm[peer_id] = new_state
        if reachable:
            target["last_direct_handshake_ts"] = now_ts()
        target["reachability_map"] = rm
        STATE["peers"][target_peer_id] = target

    if _changed:
        bump_config_version_locked()
        add_event("peer.reachability_updated", {
            "reporter": peer_id, "target": target_peer_id,
            "state": new_state,
        })
        log(f"Reachability {peer_id}→{target_peer_id}: {new_state} (config_version bumped)")

    persist()
    return {
        "reporter": peer_id, "target": target_peer_id,
        "state": new_state, "changed": _changed,
        "config_version": STATE.get("config_version", 1),
    }


# F2: nuevo endpoint admin — cambia la topología de una red existente
def network_set_topology(network_id: str, topology: str, admin_token: Optional[str] = None) -> Dict[str, Any]:
    """
    RPC: network.set_topology(network_id, topology, admin_token)
    Cambia la topología de una red existente.
    Válidos: 'hub-spoke' | 'mesh' | 'hub-mesh'  (HM-F3c)
    Hace bump de config_version para que todos los peers actualicen su config.
    Solo admin.
    """
    orch_check_admin_token(admin_token)
    topology = str(topology or "").strip()
    if topology not in VALID_TOPOLOGIES:
        raise ValueError(f"topology inválida: '{topology}'. Válidas: {sorted(VALID_TOPOLOGIES)}")
    # HM-F3c: mesh puro sigue prohibido en la red default; hub-mesh sí permitido
    if network_id == DEFAULT_NET_ID and topology == "mesh":
        raise ValueError(
            "La red 'default' no puede ser mesh puro — usa 'hub-mesh' para compatibilidad NAT"
        )

    with LOCK_NETWORKS:
        n = STATE["networks"].get(network_id)
        if not n:
            raise KeyError("network not found")
        old_topology = n.get("topology", "hub-spoke")
        if old_topology == topology:
            return {"network_id": network_id, "topology": topology, "changed": False}
        n["topology"] = topology
        STATE["networks"][network_id] = n

    new_version = bump_config_version_locked()
    persist()
    add_event("network.set_topology", {
        "network_id": network_id,
        "old_topology": old_topology,
        "new_topology": topology,
        "config_version": new_version,
    })
    log(f"Red '{network_id}': topología cambiada {old_topology} → {topology} (config_version={new_version})")
    return {"network_id": network_id, "topology": topology, "old_topology": old_topology,
            "changed": True, "config_version": new_version}


# =========================
# Advertised networks
# =========================
def peer_add_advertised_network(peer_id: str, cidr: str, network_id: str, mode_str: str, token: Optional[str] = None) -> Dict[str, Any]:
    m, uid, scopes, _ = _auth_from_token(token)
    if m == "jwt":
        _require_scope(scopes, "advertise:write")
        _enforce_tenant_for_peer(str(uid), peer_id)
        with LOCK_NETWORKS:
            if str((STATE["networks"].get(network_id) or {}).get("user_id") or "") != str(uid):
                raise PermissionError("cross-tenant forbidden")
    else:
        raise PermissionError("authentication required: provide a valid JWT")
    with LOCK_NETWORKS:
        if network_id not in STATE["networks"]:
            raise KeyError("network not found")
    with LOCK_PEERS:
        p = STATE["peers"].get(peer_id)
        if not p:
            raise KeyError("peer not found")
        adv = p.get("advertised_networks") or []
        adv_id = len(adv)
        adv.append({"adv_id": adv_id, "cidr": cidr, "network_id": network_id, "mode": mode_str})
        p["advertised_networks"] = adv
        STATE["peers"][peer_id] = p
    _hub_apply_peer_allowed_ips(peer_id)
    bump_config_version_locked()
    persist()
    add_event("peer.add_advertised_network", {"peer_id": peer_id, "cidr": cidr, "network_id": network_id})
    return {"adv_id": adv_id}


def peer_remove_advertised_network(peer_id: str, adv_id: int, token: Optional[str] = None) -> bool:
    m, uid, scopes, _ = _auth_from_token(token)
    if m == "jwt":
        _require_scope(scopes, "advertise:write")
        _enforce_tenant_for_peer(str(uid), peer_id)
    else:
        raise PermissionError("authentication required: provide a valid JWT")
    with LOCK_PEERS:
        p = STATE["peers"].get(peer_id)
        if not p:
            raise KeyError("peer not found")
        adv = [x for x in (p.get("advertised_networks") or []) if int(x.get("adv_id", -1)) != int(adv_id)]
        for i, x in enumerate(adv):
            x["adv_id"] = i
        p["advertised_networks"] = adv
        STATE["peers"][peer_id] = p
    _hub_apply_peer_allowed_ips(peer_id)
    bump_config_version_locked()
    persist()
    add_event("peer.remove_advertised_network", {"peer_id": peer_id, "adv_id": adv_id})
    return True


def peer_list_advertised_networks(peer_id: str, token: Optional[str] = None) -> List[Dict[str, Any]]:
    m, uid, scopes, _ = _auth_from_token(token)
    if m == "jwt":
        _require_scope(scopes, "advertise:read")
        _enforce_tenant_for_peer(str(uid), peer_id)
    else:
        raise PermissionError("authentication required: provide a valid JWT")
    with LOCK_PEERS:
        p = STATE["peers"].get(peer_id)
    if not p:
        raise KeyError("peer not found")
    return p.get("advertised_networks") or []


# =========================
# BOOT
# =========================
def main():
    check_dependencies()           # OPS-02
    validate_tokens_at_startup()   # SEC-01/02

    load_state()
    _ensure_default_network()
    persist()

    # EST-01: Backup automático en hilo daemon
    if BACKUP_ENABLED:
        threading.Thread(target=_backup_loop, daemon=True, name="backup-loop").start()
        log(f"Backup automático: cada {BACKUP_INTERVAL_SEC}s → {BACKUP_DIR} (máx {BACKUP_MAX_KEEP} copias)")

    log(f"Orchestrator escuchando en {ORCH_BIND}:{ORCH_PORT}")
    log("Solicitando al HUB que asegure reglas base (FORWARD/NAT)")
    try:
        hub_ensure_base_rules()
        log("Hub listo")
    except Exception as e:
        log(f"WARNING: hub.ensure_base_rules falló: {e}")

    # ESC-02: Servidor multi-thread
    server = ThreadingXMLRPCServer(
        (ORCH_BIND, ORCH_PORT), requestHandler=Handler,
        allow_none=True, logRequests=False,
    )

    server.register_function(auth_login, "auth.login")
    server.register_function(auth_refresh, "auth.refresh")
    server.register_function(auth_whoami, "auth.whoami")
    server.register_function(orch_health, "orch.health")
    server.register_function(orch_metrics, "orch.metrics")
    server.register_function(orch_events, "orch.events")
    server.register_function(orch_revoke, "orch.revoke")
    server.register_function(orch_user_create, "orch.user-create")
    server.register_function(orch_user_list, "orch.user-list")
    server.register_function(orch_user_get, "orch.user-get")
    server.register_function(orch_user_delete, "orch.user-delete")
    server.register_function(orch_issue_user_token, "orch.issue-user-token")
    server.register_function(peer_register, "peer.register")
    server.register_function(peer_unregister, "peer.unregister")
    server.register_function(peer_update, "peer.update")
    server.register_function(peer_update_admin, "peer.update_admin")
    server.register_function(peer_heartbeat, "peer.heartbeat")
    server.register_function(peer_rotate_key, "peer.rotate_key")
    server.register_function(peer_get_status, "peer.get_status")
    server.register_function(peer_list, "peer.list")
    server.register_function(peer_get, "peer.get")
    server.register_function(peer_request_network, "peer.request_network")
    server.register_function(peer_assign_network, "peer.assign_network")
    server.register_function(peer_remove_from_network, "peer.remove_from_network")
    server.register_function(peer_report_reachability, "peer.report_reachability")  # HM-F2c
    server.register_function(config_get_peer_config, "config.get_peer_config")
    server.register_function(config_get_config_diff, "config.get_config_diff")
    server.register_function(config_get_mesh_peers,  "config.get_mesh_peers")   # F2: mesh
    server.register_function(network_create, "network.create")
    server.register_function(network_delete, "network.delete")
    server.register_function(network_list, "network.list")
    server.register_function(network_get, "network.get")
    server.register_function(network_get_topology, "network.get_topology")
    server.register_function(network_alloc_ip, "network.alloc_ip")
    server.register_function(network_set_topology, "network.set_topology")      # F2: mesh
    server.register_function(peer_add_advertised_network, "peer.add_advertised_network")
    server.register_function(peer_remove_advertised_network, "peer.remove_advertised_network")
    server.register_function(peer_list_advertised_networks, "peer.list_advertised_networks")

    log("Orchestrator listo (multi-thread habilitado)")
    server.serve_forever()


if __name__ == "__main__":
    main()
